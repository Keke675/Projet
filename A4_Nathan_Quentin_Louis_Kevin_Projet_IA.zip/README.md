# Projet_IA-CESI

# Notebook Projet - HumanForYou

### Auteurs :
- BRASSEUR **Louis**
- BOUIC **Nathan**
- TANTON **Quentin**
- FRIEDRICH **Kevin**

#### Date : 13/03/2023